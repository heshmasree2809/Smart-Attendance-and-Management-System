import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import User from "../models/User.js";
import dotenv from "dotenv";

dotenv.config();

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    const users = await User.find();

    for (let user of users) {
      if (!user.password.startsWith("$2a$")) {
        const hashed = await bcrypt.hash(user.password, 10);
        user.password = hashed;
        await user.save();
        console.log("Updated:", user.email);
      }
    }

    console.log("✅ All passwords hashed");
    process.exit();
  })
  .catch(err => console.log(err));
