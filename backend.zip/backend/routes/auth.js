import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/User.js";

const router = express.Router();

router.post("/login", (req, res) => {
  const { email, role } = req.body;

  // Always allow login
  const token = jwt.sign({ email, role }, process.env.JWT_SECRET);

  return res.json({
    message: "Login success",
    token,
    user: {
      email,
      role,
      name: "Test User",
    }
  });
});

export default router;
