// routes/faculty.js
import express from "express";
import auth from "../middleware/auth.js";
import { allowRoles } from "../middleware/roles.js";
import { facultyAttendance, facultyAssignments } from "../controllers/facultyController.js";

const router = express.Router();
router.use(auth, allowRoles("faculty", "admin"));

router.get("/attendance", facultyAttendance);
router.get("/assignments", facultyAssignments);

export default router;
