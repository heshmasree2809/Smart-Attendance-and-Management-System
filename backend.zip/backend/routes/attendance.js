// routes/attendance.js
import express from "express";
import auth from "../middleware/auth.js";
import { allowRoles } from "../middleware/roles.js";
import { generateQR, markAttendance, getByFaculty, getByStudent } from "../controllers/attendanceController.js";

const router = express.Router();

// (Optional) QR payload generator
router.post("/generate", auth, allowRoles("faculty", "admin"), generateQR);

// Student submit after scan (can be unauthenticated if you want; here we require login)
router.post("/mark", auth, markAttendance);

// Faculty & Student views
router.get("/faculty", auth, allowRoles("faculty", "admin"), getByFaculty);
router.get("/student", auth, allowRoles("student"), getByStudent);

export default router;
