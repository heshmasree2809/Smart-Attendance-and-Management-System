// routes/student.js
import express from "express";
import auth from "../middleware/auth.js";
import { allowRoles } from "../middleware/roles.js";
import { myAttendance, myAssignments, myMarks } from "../controllers/studentController.js";

const router = express.Router();
router.use(auth, allowRoles("student"));

router.get("/attendance", myAttendance);
router.get("/assignments", myAssignments);
router.get("/marks", myMarks);

export default router;
