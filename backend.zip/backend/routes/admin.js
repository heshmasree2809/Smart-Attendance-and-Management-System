// routes/admin.js
import express from "express";
import auth from "../middleware/auth.js";
import { allowRoles } from "../middleware/roles.js";
import {
  stats,
  allUsers, createUser, updateUser, deleteUser,
  getDepartments, createDepartment, updateDepartment, deleteDepartment,
  getCourses, createCourse, updateCourse, deleteCourse,
  getNotices, createNotice, updateNotice, deleteNotice
} from "../controllers/adminController.js";

const router = express.Router();
router.use(auth, allowRoles("admin"));

router.get("/stats", stats);

// Users
router.get("/users", allUsers);
router.post("/users", createUser);
router.put("/users/:id", updateUser);
router.delete("/users/:id", deleteUser);

// Departments
router.get("/departments", getDepartments);
router.post("/departments", createDepartment);
router.put("/departments/:id", updateDepartment);
router.delete("/departments/:id", deleteDepartment);

// Courses
router.get("/courses", getCourses);
router.post("/courses", createCourse);
router.put("/courses/:id", updateCourse);
router.delete("/courses/:id", deleteCourse);

// Notices
router.get("/notices", getNotices);
router.post("/notices", createNotice);
router.put("/notices/:id", updateNotice);
router.delete("/notices/:id", deleteNotice);

export default router;
