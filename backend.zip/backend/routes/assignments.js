// routes/assignments.js
import express from "express";
import multer from "multer";
import auth from "../middleware/auth.js";
import { allowRoles } from "../middleware/roles.js";
import {
  createAssignment,
  submitAssignment,
  allFacultyAssignments,
  allStudentAssignments,
  gradeSubmission,
} from "../controllers/assignmentController.js";

const router = express.Router();
const upload = multer({ dest: "uploads/" });

// Faculty
router.post("/create", auth, allowRoles("faculty", "admin"), upload.array("files"), createAssignment);
router.get("/faculty", auth, allowRoles("faculty", "admin"), allFacultyAssignments);
router.post("/:id/grade", auth, allowRoles("faculty", "admin"), gradeSubmission);

// Student
router.get("/student", auth, allowRoles("student"), allStudentAssignments);
router.post("/submit/:id", auth, allowRoles("student"), upload.array("files"), submitAssignment);

export default router;
